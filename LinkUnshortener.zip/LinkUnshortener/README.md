# LinkUnshortener (Android, Kotlin + Jetpack Compose)

Expande links encurtados **dentro do próprio app** (OkHttp no aparelho), sem servidor, sem API paga e sem WebView.

## Como executar
1. Instale o Android Studio (Koala ou mais recente) com Android SDK 34.
2. `File > Open` e escolha a pasta `LinkUnshortener`. Aguarde o Gradle sincronizar (precisa de internet na primeira vez).
3. Conecte um celular com depuração USB ou abra um emulador e clique em **Run ▶**.
4. Para gerar o APK: `Build > Build APK(s)` → `app/build/outputs/apk/debug/app-debug.apk`.
   Pelo terminal: `gradle assembleDebug` (ou `./gradlew assembleDebug` depois que o Studio criar o wrapper).

Dica: em outro app, use **Compartilhar → LinkUnshortener** para expandir um link sem copiar e colar.

## Como funciona
- `Unshortener.kt`: segue cada salto manualmente (HTTP 3xx), detecta `meta refresh` e redirecionamentos JavaScript simples
  por **análise estática** da página (sem executar JS), limita a 10 saltos, detecta loops e classifica o encurtador
  (lista conhecida + heurística para desconhecidos).
- `SafeDns` (em `Unshortener.kt`): bloqueia localhost, loopback, redes privadas, link-local, CGNAT e IPv6 ULA em **cada salto**
  e na própria conexão (evita SSRF e DNS rebinding). Só portas 80/443.
- `Security.kt`: alertas heurísticos locais (imitação de marcas, IP no lugar de domínio, punycode, TLDs de golpe,
  usuário@host, HTTP sem TLS, executáveis/arquivos, página com campo de senha, cadeia longa/vários encurtadores).
- O app lê só cabeçalhos e até 256 KB de HTML; nunca salva, abre ou executa arquivos, não usa cookies e não preenche formulários.

## Limitações (por design)
- CAPTCHA, login, páginas "aguarde X segundos / clique para continuar" (ex.: adf.ly, linkvertise) e bloqueio anti-bot:
  o app **informa a limitação** e não tenta contornar.
- JavaScript ofuscado ou que depende de execução real não é resolvido.
- Alguns servidores respondem diferente a apps do que a navegadores.
- Detecção de phishing é heurística, sem lista negra online: ausência de alerta não garante segurança.
- Código não foi compilado no ambiente em que foi gerado; se o Gradle reclamar de versão, ajuste em `build.gradle.kts`.
