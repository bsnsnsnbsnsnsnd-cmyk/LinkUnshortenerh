package com.linkunshortener.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.format.DateUtils
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT) else null
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(shared.orEmpty())
                }
            }
        }
    }
}

fun extractUrls(text: String): List<String> {
    val m = Patterns.WEB_URL.matcher(text)
    val out = linkedSetOf<String>()
    while (m.find() && out.size < 20) out += m.group()
    return out.toList()
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("url", text))
    Toast.makeText(ctx, "Copiado", Toast.LENGTH_SHORT).show()
}

@Composable
fun App(initial: String) {
    val ctx = LocalContext.current
    val store = remember { HistoryStore(ctx) }
    val scope = rememberCoroutineScope()
    val limiter = remember { Semaphore(4) }
    var input by remember { mutableStateOf(initial) }
    var results by remember { mutableStateOf<List<Expansion>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(store.load()) }

    suspend fun process(urls: List<String>) {
        loading = true
        try {
            val out = withContext(Dispatchers.IO) {
                coroutineScope { urls.map { u -> async { limiter.withPermit { Unshortener.expand(u) } } }.awaitAll() }
            }
            results = out
            store.add(out)
            history = store.load()
        } finally {
            loading = false
        }
    }

    // Processamento automático: 0,9 s depois de colar/digitar um link
    LaunchedEffect(input) {
        val urls = extractUrls(input)
        if (urls.isEmpty()) results = emptyList() else { delay(900); process(urls) }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("LinkUnshortener", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(
                "Descubra para onde um link encurtado realmente leva, sem abrir a página.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                label = { Text("Cole um ou mais links") },
                modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 8,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
                    if (!t.isNullOrBlank()) input = t
                }) { Text("Colar") }
                Button(enabled = !loading, onClick = {
                    val urls = extractUrls(input)
                    if (urls.isEmpty()) Toast.makeText(ctx, "Nenhum link encontrado", Toast.LENGTH_SHORT).show()
                    else scope.launch { process(urls) }
                }) { Text("Expandir") }
                TextButton(onClick = { input = "" }) { Text("Limpar") }
            }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        items(results) { ResultCard(it) }
        if (history.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Histórico", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { store.clear(); history = emptyList() }) { Text("Limpar histórico") }
                }
            }
            items(history) { h -> HistoryRow(h) }
        }
    }
}

private fun riskColor(r: Risk) = when (r) {
    Risk.HIGH -> Color(0xFFC62828)
    Risk.MEDIUM -> Color(0xFFF9A825)
    Risk.LOW -> Color(0xFF2E7D32)
}

@Composable
fun ResultCard(r: Expansion) {
    val ctx = LocalContext.current
    var showChain by remember { mutableStateOf(false) }
    val color = if (r.status != Status.OK) Color(0xFFEF6C00) else riskColor(r.risk)
    val label = when {
        r.status == Status.BLOCKED -> "Bloqueado"
        r.status == Status.LIMITED -> "Limitação"
        r.status == Status.ERROR -> "Erro"
        r.risk == Risk.HIGH -> "Suspeito"
        r.risk == Risk.MEDIUM -> "Atenção"
        else -> "Sem alertas"
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(color, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(label, color = color, fontWeight = FontWeight.Bold)
            }
            Text(r.kind, style = MaterialTheme.typography.labelMedium)
            Text(r.input, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            val dest = r.finalUrl
            if (dest != null) {
                Text("Destino", style = MaterialTheme.typography.labelMedium)
                SelectionContainer { Text(dest, fontWeight = FontWeight.Medium) }
            }
            Text(r.message, style = MaterialTheme.typography.bodyMedium)
            r.warnings.forEach {
                Text("⚠ $it", style = MaterialTheme.typography.bodySmall,
                    color = if (r.risk == Risk.HIGH) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (dest != null) Button(onClick = { copyText(ctx, dest) }) { Text("Copiar") }
                if (r.hops.size > 1) TextButton(onClick = { showChain = !showChain }) {
                    Text(if (showChain) "Ocultar cadeia" else "Ver cadeia (${r.hops.size})")
                }
            }
            if (showChain) r.hops.forEachIndexed { i, h ->
                Text("${i + 1}. [${h.code}] ${h.url}\n    ${h.via}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun HistoryRow(h: HistoryItem) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable { copyText(ctx, h.finalUrl) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).background(riskColor(h.risk), CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(h.finalUrl, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${h.input} · ${DateUtils.getRelativeTimeSpanString(h.time)} · toque para copiar",
                style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
