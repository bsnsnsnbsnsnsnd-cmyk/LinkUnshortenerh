package com.linkunshortener.app

import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

enum class Status { OK, LIMITED, BLOCKED, ERROR }
enum class Risk { LOW, MEDIUM, HIGH }

data class Hop(val url: String, val code: Int, val via: String)

data class Expansion(
    val input: String,
    val finalUrl: String?,
    val hops: List<Hop>,
    val status: Status,
    val message: String,
    val kind: String,
    val warnings: List<String>,
    val risk: Risk,
)

class BlockedAddressException(message: String) : IOException(message)

/** DNS que recusa endereços locais/privados. Como é o próprio OkHttp que usa esta resolução
 *  para conectar, não há janela para DNS rebinding (mesma resposta validada = mesma conexão). */
object SafeDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val h = hostname.lowercase().trimEnd('.')
        if (h == "localhost" || h.endsWith(".localhost") || h.endsWith(".local") ||
            h.endsWith(".internal") || h.endsWith(".lan") || h.endsWith(".home.arpa")
        ) throw BlockedAddressException("Host local bloqueado: $h")
        val all = Dns.SYSTEM.lookup(hostname)
        all.forEach {
            if (isPrivate(it)) throw BlockedAddressException(
                "$hostname aponta para rede local/privada (${it.hostAddress}). Bloqueado por segurança (SSRF)."
            )
        }
        return all
    }

    fun isPrivate(a: InetAddress): Boolean {
        if (a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress ||
            a.isSiteLocalAddress || a.isMulticastAddress
        ) return true
        val b = a.address
        if (b.size == 4) {
            val b0 = b[0].toInt() and 0xff
            val b1 = b[1].toInt() and 0xff
            val b2 = b[2].toInt() and 0xff
            if (b0 == 0 || b0 >= 240) return true                    // 0.0.0.0/8, reservado/broadcast
            if (b0 == 100 && b1 in 64..127) return true              // CGNAT 100.64/10
            if (b0 == 198 && (b1 == 18 || b1 == 19)) return true     // benchmark
            if (b0 == 192 && b1 == 0 && b2 == 0) return true         // 192.0.0.0/24
        } else if (b.size == 16) {
            if ((b[0].toInt() and 0xfe) == 0xfc) return true         // fc00::/7 (ULA)
        }
        return false
    }
}

object Unshortener {
    const val MAX_REDIRECTS = 10
    private const val MAX_BODY = 256 * 1024L
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    val KNOWN = setOf(
        "bit.ly", "bitly.com", "j.mp", "tinyurl.com", "is.gd", "v.gd", "t.co", "cutt.ly", "rebrand.ly",
        "rb.gy", "ow.ly", "buff.ly", "goo.gl", "t.ly", "shorturl.at", "tiny.cc", "lnkd.in", "youtu.be",
        "amzn.to", "a.co", "fb.me", "bl.ink", "s.id", "short.io", "bit.do", "adf.ly", "smarturl.it",
        "dlvr.it", "trib.al", "w.wiki", "g.co", "mcaf.ee", "clck.ru", "href.li", "lnk.to", "qr.ae", "x.co",
    )

    // Sem cookie jar, sem autenticação, sem seguir redirecionamentos automaticamente.
    private val client = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .dns(SafeDns)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private val metaRe = Regex(
        """<meta[^>]+http-equiv\s*=\s*["']?refresh["']?[^>]*content\s*=\s*["']\s*(\d+)\s*;\s*url\s*=\s*['"]?([^"'>\s]+)""",
        RegexOption.IGNORE_CASE
    )
    private val jsRe = Regex(
        """(?:window\.|document\.|top\.|self\.)?location(?:\.href)?\s*=\s*["']([^"']+)["']|location\.(?:replace|assign)\(\s*["']([^"']+)["']\s*\)""",
        RegexOption.IGNORE_CASE
    )
    private val challengeRe = Regex(
        "captcha|cf-chl|just a moment|attention required|verify you are human|are you a robot|enable javascript and cookies",
        RegexOption.IGNORE_CASE
    )

    private class Page(val code: Int, val location: String?, val download: Boolean, val body: String?)

    fun normalize(raw: String): HttpUrl? {
        var s = raw.trim().trim('<', '>', '"', '\'', '(', ')', ',', '.')
        if (s.isEmpty()) return null
        if (!s.contains("://")) s = "https://$s"
        val u = s.toHttpUrlOrNull() ?: return null
        return if (u.scheme == "http" || u.scheme == "https") u else null
    }

    fun registrable(host: String): String {
        val l = host.lowercase().trimEnd('.').split('.')
        if (l.size <= 2) return l.joinToString(".")
        val sld = setOf("com", "co", "org", "net", "gov", "edu", "ac")
        return if (l.last().length == 2 && l[l.size - 2] in sld) l.takeLast(3).joinToString(".")
        else l.takeLast(2).joinToString(".")
    }

    fun isKnown(host: String) = registrable(host) in KNOWN

    /** Resolve o link seguindo HTTP 3xx, meta refresh e redirecionamentos JS simples (análise estática). */
    fun expand(raw: String): Expansion {
        val start = normalize(raw) ?: return Expansion(
            raw, null, emptyList(), Status.ERROR, "URL inválida.", "—", emptyList(), Risk.LOW
        )
        val hops = mutableListOf<Hop>()
        val visited = HashSet<String>()
        var current: HttpUrl = start
        var via = "Link original"
        var redirects = 0

        fun known(): HttpUrl? = if (redirects > 0) current else null

        fun done(
            status: Status, msg: String, finalUrl: HttpUrl?, body: String? = null,
            download: Boolean = false, extra: List<String> = emptyList(),
        ): Expansion {
            val chain = hops.mapNotNull { it.url.toHttpUrlOrNull() }
            val (warn, risk) = if (finalUrl != null) Security.analyze(chain, finalUrl, body, download)
            else Pair(emptyList(), Risk.LOW)
            return Expansion(raw, finalUrl?.toString(), hops.toList(), status, msg,
                classify(start, finalUrl, redirects), extra + warn, risk)
        }

        while (true) {
            if (!visited.add(current.toString()))
                return done(Status.LIMITED, "Loop de redirecionamento detectado.", known())
            if (current.port != 80 && current.port != 443)
                return done(Status.BLOCKED, "Porta ${current.port} não permitida (apenas 80 e 443).", known())
            try {
                SafeDns.lookup(current.host) // valida também IPs literais antes de conectar
            } catch (e: BlockedAddressException) {
                return done(Status.BLOCKED, e.message ?: "Destino bloqueado.", known())
            } catch (e: IOException) {
                return done(Status.ERROR, describe(e), known())
            }

            val page = try {
                fetch(current)
            } catch (e: IOException) {
                val blocked = generateSequence<Throwable>(e) { it.cause }.firstOrNull { it is BlockedAddressException }
                return if (blocked != null) done(Status.BLOCKED, blocked.message ?: "Destino bloqueado.", known())
                else done(Status.ERROR, describe(e), known())
            }
            hops += Hop(current.toString(), page.code, via)

            // 1) Redirecionamento HTTP
            val location = page.location
            if (page.code in 300..399 && location != null) {
                val n = current.resolve(location)
                    ?: return done(Status.LIMITED, "Redireciona para um link fora da web: ${location.take(200)}", null)
                if (++redirects > MAX_REDIRECTS)
                    return done(Status.LIMITED, "Limite de $MAX_REDIRECTS redirecionamentos atingido.", n)
                current = n; via = "HTTP ${page.code}"
                continue
            }

            val body = page.body

            // 2) CAPTCHA / login / bloqueio anti-bot: informa, não contorna
            if (page.code in setOf(401, 403, 429, 503) ||
                (body != null && body.length < 20000 && challengeRe.containsMatchIn(body))
            ) return done(
                Status.LIMITED,
                "O servidor exige verificação humana/login ou bloqueou acesso automático (HTTP ${page.code}). " +
                    "O app não tenta contornar isso.", known()
            )

            // 3) Redirecionamento do lado do cliente (meta refresh / JS simples), sem executar JavaScript
            if (body != null) {
                val c = clientRedirect(current, body)
                if (c != null && c.first.toString() != current.toString()) {
                    if (++redirects > MAX_REDIRECTS)
                        return done(Status.LIMITED, "Limite de $MAX_REDIRECTS redirecionamentos atingido.", c.first)
                    current = c.first; via = c.second
                    continue
                }
            }

            // 4) Destino final
            val extra = mutableListOf<String>()
            if (page.code >= 400) extra += "O destino respondeu HTTP ${page.code}."
            val msg = if (redirects == 0) "Nenhum redirecionamento encontrado."
            else "Destino encontrado após $redirects redirecionamento(s)."
            return done(Status.OK, msg, current, body, page.download, extra)
        }
    }

    // Lê apenas cabeçalhos e até 256 KB de HTML. Nunca salva, abre ou executa arquivos.
    private fun fetch(url: HttpUrl): Page {
        val req = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
            .build()
        return client.newCall(req).execute().use { r ->
            val ct = r.header("Content-Type")?.lowercase().orEmpty()
            val cd = r.header("Content-Disposition")?.lowercase().orEmpty()
            val textual = ct.isEmpty() || ct.startsWith("text/html") || ct.startsWith("application/xhtml")
            val binary = ct.startsWith("application/") &&
                !ct.contains("json") && !ct.contains("xml") && !ct.startsWith("application/xhtml")
            val download = r.code in 200..299 && (cd.contains("attachment") || binary)
            val isRedirect = r.code in 300..399
            val body = if (!isRedirect && textual && !download) r.peekBody(MAX_BODY).string() else null
            Page(r.code, r.header("Location"), download, body)
        }
    }

    private fun clientRedirect(base: HttpUrl, body: String): Pair<HttpUrl, String>? {
        metaRe.find(body)?.let { m ->
            val delay = m.groupValues[1].toIntOrNull() ?: 0
            if (delay <= 5) base.resolve(clean(m.groupValues[2]))?.let { return it to "meta refresh" }
        }
        // JS só é considerado em páginas pequenas (interstitials) ou de encurtadores conhecidos
        if (body.length < 6000 || isKnown(base.host)) {
            jsRe.find(body)?.let { m ->
                val raw = m.groupValues[1].ifEmpty { m.groupValues[2] }
                base.resolve(clean(raw))?.let { return it to "JavaScript (análise estática)" }
            }
        }
        return null
    }

    private fun clean(s: String) =
        s.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&").trim()

    private fun classify(start: HttpUrl, fin: HttpUrl?, redirects: Int): String {
        val segs = start.pathSegments.filter { it.isNotEmpty() }
        val shortLike = segs.size == 1 && segs[0].length <= 12 && '.' !in segs[0]
        return when {
            isKnown(start.host) -> "Encurtador conhecido (${registrable(start.host)})"
            redirects > 0 && fin != null && shortLike &&
                registrable(start.host) != registrable(fin.host) ->
                "Provável encurtador desconhecido (${start.host})"
            redirects > 0 -> "Redirecionamento comum"
            else -> "Sem redirecionamento"
        }
    }

    private fun describe(e: IOException) = when (e) {
        is UnknownHostException -> "Domínio não encontrado (link inexistente ou sem internet)."
        is SocketTimeoutException -> "Tempo esgotado ao contatar o servidor."
        is SSLException -> "Falha de certificado/TLS no destino."
        else -> "Erro de rede: ${e.message ?: e.javaClass.simpleName}"
    }
}
