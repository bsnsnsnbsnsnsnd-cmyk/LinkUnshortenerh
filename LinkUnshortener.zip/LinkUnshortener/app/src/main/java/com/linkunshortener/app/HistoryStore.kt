package com.linkunshortener.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(val input: String, val finalUrl: String, val risk: Risk, val time: Long)

class HistoryStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> = runCatching {
        val a = JSONArray(sp.getString("items", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(o.getString("i"), o.getString("f"), Risk.valueOf(o.getString("r")), o.getLong("t"))
        }
    }.getOrDefault(emptyList())

    fun add(results: List<Expansion>) {
        val fresh = results.filter { it.status == Status.OK && it.finalUrl != null }
            .map { HistoryItem(it.input, it.finalUrl!!, it.risk, System.currentTimeMillis()) }
        if (fresh.isEmpty()) return
        save((fresh + load()).distinctBy { it.input }.take(50))
    }

    fun clear() { sp.edit().remove("items").apply() }

    private fun save(list: List<HistoryItem>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("i", it.input).put("f", it.finalUrl).put("r", it.risk.name).put("t", it.time))
        }
        sp.edit().putString("items", a.toString()).apply()
    }
}
