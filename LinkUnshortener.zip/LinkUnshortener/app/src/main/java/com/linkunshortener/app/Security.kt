package com.linkunshortener.app

import okhttp3.HttpUrl

/** Heurísticas locais (sem APIs externas). A ausência de alertas NÃO garante que o link é seguro. */
object Security {
    private val badTld = setOf("zip", "mov", "tk", "ml", "ga", "cf", "gq", "top", "xyz", "click",
        "country", "work", "rest", "icu", "cyou", "buzz", "loan", "monster")
    private val executable = setOf("apk", "exe", "msi", "bat", "cmd", "scr", "jar", "vbs", "ps1", "dmg", "pkg", "sh", "lnk")
    private val archive = setOf("zip", "rar", "7z", "iso")
    private val brands = listOf("paypal", "apple", "google", "microsoft", "amazon", "netflix", "facebook",
        "instagram", "whatsapp", "nubank", "itau", "bradesco", "caixa", "santander", "mercadolivre",
        "mercadopago", "correios")
    private val words = listOf("login", "signin", "verify", "verification", "secure", "account", "update",
        "wallet", "password", "senha", "confirm", "bank", "pix", "suporte", "billing")
    private val ipRe = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")
    private val pwRe = Regex("""<input[^>]+type\s*=\s*["']?password""", RegexOption.IGNORE_CASE)

    fun analyze(chain: List<HttpUrl>, fin: HttpUrl, body: String?, download: Boolean): Pair<List<String>, Risk> {
        val w = mutableListOf<String>()
        var score = 0
        fun add(points: Int, msg: String) { score += points; w += msg }

        val host = fin.host.lowercase()
        val ext = fin.pathSegments.lastOrNull()?.substringAfterLast('.', "")?.lowercase().orEmpty()

        if (fin.scheme == "http") add(1, "O destino não usa HTTPS (conexão sem criptografia).")
        if (fin.username.isNotEmpty() || fin.password.isNotEmpty())
            add(3, "O endereço contém usuário/senha embutidos (truque comum de phishing).")
        if (ipRe.matches(host) || host.contains(':')) add(3, "O destino é um endereço IP, não um domínio.")
        if (host.split('.').any { it.startsWith("xn--") })
            add(2, "Domínio com caracteres internacionais (punycode); pode imitar outro site.")
        val tld = host.substringAfterLast('.')
        if (tld in badTld) add(2, "A extensão .$tld é muito usada em golpes.")
        if (host.split('.').size >= 5) add(1, "Muitos subdomínios no endereço.")

        val reg = Unshortener.registrable(host)
        val regLabel = reg.substringBefore('.')
        val tokens = host.split('.', '-')
        brands.firstOrNull { it in tokens && regLabel != it }?.let {
            add(4, "O endereço cita \"$it\", mas o domínio real é $reg. Possível imitação.")
        }
        if (words.any { it in host + fin.encodedPath.lowercase() })
            add(1, "Contém termos típicos de golpes de login/verificação.")

        if (ext in executable) add(4, "Aponta para um arquivo executável (.$ext). Não instale nem abra.")
        else if (download || ext in archive)
            add(2, "Aponta para um download de arquivo${if (ext.isNotEmpty()) " (.$ext)" else ""}. O app não baixa nem executa arquivos.")

        if (body != null && pwRe.containsMatchIn(body))
            add(2, "A página de destino pede senha. Não digite credenciais em páginas chegadas por link encurtado.")

        val shorteners = chain.map { Unshortener.registrable(it.host) }.filter { it in Unshortener.KNOWN }.distinct()
        if (shorteners.size >= 2) add(1, "O link passa por vários encurtadores (${shorteners.joinToString()}).")
        if (chain.size > 5) add(1, "Cadeia longa de redirecionamentos (${chain.size} saltos).")

        val risk = when {
            score >= 4 -> Risk.HIGH
            score >= 2 -> Risk.MEDIUM
            else -> Risk.LOW
        }
        return w to risk
    }
}
